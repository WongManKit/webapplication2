/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.admin.model;

import java.io.Serializable;

public class Manager implements Serializable {
    private int managerId;
    private String fullName;
    private String email;
    private String username;
    private String password;
    private boolean isAdmin;
    
    // Constructors, Getters and Setters
    public Manager() {}
    
    public Manager(String fullName, String email, String username, String password, boolean isAdmin) {
        this.fullName = fullName;
        this.email = email;
        this.username = username;
        this.password = password;
        this.isAdmin = isAdmin;
    }
    
    // Add all getters and setters here managerId
   public int getManegerId() { return managerId; }
    public void setManagerId(int managerId) { this.managerId = managerId; }
    
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    
    public boolean getAdmin() { return isAdmin; }
    public void setAdmin(boolean isAdmin) { this.isAdmin = isAdmin; }
}
