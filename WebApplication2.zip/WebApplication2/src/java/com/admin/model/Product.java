/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.admin.model;


import java.io.Serializable;

public class Product implements Serializable {
    private int productId;
    private String name;
    private String sizeType;
    private String category;
    private double price;
    private int stock;
    
    // Constructors
    public Product() {}
    
    public Product(String name, String sizeType, String category, double price, int stock) {
        this.name = name;
        this.sizeType = sizeType;
        this.category = category;
        this.price = price;
        this.stock = stock;
    }
    
    // Getters and Setters
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getSizeType() { return sizeType; }
    public void setSizeType(String sizeType) { this.sizeType = sizeType; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
}