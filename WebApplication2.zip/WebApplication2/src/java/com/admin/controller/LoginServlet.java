/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.admin.controller;

import com.admin.dao.ManagerDAO;
import com.admin.model.Manager;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        try {
            Manager manager = new ManagerDAO().authenticate(username, password);
            if (manager != null) {
                request.getSession().setAttribute("manager", manager);
                response.sendRedirect(request.getContextPath() + "admin/dashboard.jsp");
            } else {
                response.sendRedirect(request.getContextPath() + "login.jsp?error=1");
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}