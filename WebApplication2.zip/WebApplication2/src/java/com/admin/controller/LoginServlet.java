/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.admin.controller;

import com.admin.dao.ManagerDAO;
import com.admin.model.Manager;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private ManagerDAO managerDao;
    
    @Override
    public void init() {
        managerDao = new ManagerDAO();
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        try {
            Manager manager = managerDao.authenticate(username, password);
            
            if (manager != null) {
                HttpSession session = request.getSession();
                session.setAttribute("manager", manager);
                response.sendRedirect("adminDashboard.jsp");
            } else {
                response.sendRedirect("login.jsp?error=1");
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
}