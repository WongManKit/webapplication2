/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.admin.dao;


import com.admin.model.Staff;
import com.admin.util.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StaffDAO {
    // SQL queries
    private static final String INSERT_SQL = "INSERT INTO staff (full_name, email, username, password) VALUES (?, ?, ?, ?)";
    private static final String SELECT_BY_ID_SQL = "SELECT * FROM staff WHERE staff_id = ?";
    private static final String SELECT_ALL_SQL = "SELECT * FROM staff";
    private static final String UPDATE_SQL = "UPDATE staff SET full_name = ?, email = ?, username = ?, password = ? WHERE staff_id = ?";
    private static final String DELETE_SQL = "DELETE FROM staff WHERE staff_id = ?";
    private static final String AUTHENTICATE_SQL = "SELECT * FROM staff WHERE username = ? AND password = ?";
    
    // Add a new staff
    public boolean addStaff(Staff staff) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(INSERT_SQL)) {
            
            stmt.setString(1, staff.getFullName());
            stmt.setString(2, staff.getEmail());
            stmt.setString(3, staff.getUsername());
            stmt.setString(4, staff.getPassword());
            
            return stmt.executeUpdate() > 0;
        }catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Get staff by ID
    public Staff getStaffById(int id) throws SQLException {
        Staff staff = null;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SELECT_BY_ID_SQL)) {
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                staff = new Staff();
                staff.setStaffId(rs.getInt("staff_id"));
                staff.setFullName(rs.getString("full_name"));
                staff.setEmail(rs.getString("email"));
                staff.setUsername(rs.getString("username"));
                staff.setPassword(rs.getString("password"));
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return staff;
    }
    
    // Get all staff
    public List<Staff> getAllStaff() throws SQLException {
        List<Staff> staffList = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SELECT_ALL_SQL);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Staff staff = new Staff();
                staff.setStaffId(rs.getInt("staff_id"));
                staff.setFullName(rs.getString("full_name"));
                staff.setEmail(rs.getString("email"));
                staff.setUsername(rs.getString("username"));
                staff.setPassword(rs.getString("password"));
                
                staffList.add(staff);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return staffList;
    }
    
    // Update staff
    public boolean updateStaff(Staff staff) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(UPDATE_SQL)) {
            
            stmt.setString(1, staff.getFullName());
            stmt.setString(2, staff.getEmail());
            stmt.setString(3, staff.getUsername());
            stmt.setString(4, staff.getPassword());
            stmt.setInt(5, staff.getStaffId());
            
            return stmt.executeUpdate() > 0;
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Delete staff
    public boolean deleteStaff(int id) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(DELETE_SQL)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Authenticate staff
    public Staff authenticate(String username, String password) throws SQLException {
        Staff staff = null;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(AUTHENTICATE_SQL)) {
            
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                staff = new Staff();
                staff.setStaffId(rs.getInt("staff_id"));
                staff.setFullName(rs.getString("full_name"));
                staff.setEmail(rs.getString("email"));
                staff.setUsername(rs.getString("username"));
                staff.setPassword(rs.getString("password"));
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return staff;
        
    }
    
}
