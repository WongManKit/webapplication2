/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.admin.dao;

import com.admin.model.Manager;
import com.admin.util.DatabaseConnection;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ManagerDAO {
    private static final String AUTHENTICATE_SQL = "SELECT * FROM manager WHERE username = ? AND password = ?";
    
    public Manager authenticate(String username, String password) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(AUTHENTICATE_SQL)) {
            
            stmt.setString(1, username);
            stmt.setString(2, password);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Manager manager = new Manager();
                manager.setManagerId(rs.getInt("manager_id"));
                manager.setFullName(rs.getString("full_name"));
                manager.setEmail(rs.getString("email"));
                manager.setUsername(rs.getString("username"));
                manager.setPassword(rs.getString("password"));
                manager.setAdmin(rs.getBoolean("is_admin"));
                return manager;
            }
            return null;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ManagerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
    
}
